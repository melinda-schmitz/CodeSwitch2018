/* eslint-env node */

module.exports = require('./lib/src/addons/MomentLocaleUtils');
module.exports.localeUtils = require('./lib/src/addons/MomentLocaleUtils');
