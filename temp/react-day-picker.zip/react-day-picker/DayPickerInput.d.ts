import { DayPickerInput } from './types/DayPickerInput'
export default DayPickerInput
